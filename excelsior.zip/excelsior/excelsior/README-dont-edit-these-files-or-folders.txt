[Do not edit files or folders in the Excelsior core folder](https://github.com/nys-its/excelsior/wiki/Understanding-the-Template#excelsior-core-folder)

If you edit these files you may have a hard time upgrading Excelsior. Utilize the project-asset folder to override Excelsior defaults.