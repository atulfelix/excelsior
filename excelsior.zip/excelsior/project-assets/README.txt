Place all of your project-specific assets here. You can override all Excelsior defaults with your own CSS/JS.

[What is the "project-assets" folder?](https://github.com/nys-its/excelsior/wiki/Understanding-the-Template#files-you-should-edit)